<?php
/**
 * Plugin Name:       A1 Tools
 * Plugin URI:        https://tools.a-1chimney.com
 * Description:       Connects your WordPress site to the A1 Tools platform for centralized management of contact information, social media links, and business details.
 * Version:           1.0.7
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Author:            A1 Chimney Service
 * Author URI:        https://a-1chimney.com
 * Text Domain:       a1-tools
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants.
define( 'A1_TOOLS_VERSION', '1.0.7' );
define( 'A1_TOOLS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'A1_TOOLS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'A1_TOOLS_DEFAULT_API_URL', 'https://tools.a-1chimney.com/api/website_variables.php' );
define( 'A1_TOOLS_CACHE_KEY', 'a1_tools_site_variables' );
define( 'A1_TOOLS_CACHE_EXPIRY', HOUR_IN_SECONDS );

/**
 * Get site variables from API or cache.
 *
 * @since 1.0.0
 * @param bool $force_refresh Force a fresh API call.
 * @return array|null Variables array or null on error.
 */
function a1_tools_get_site_variables( $force_refresh = false ) {
	// Check cache first.
	if ( ! $force_refresh ) {
		$cached = get_transient( A1_TOOLS_CACHE_KEY );
		if ( false !== $cached ) {
			return $cached;
		}
	}

	// Fetch from API.
	$site_url = site_url();

	/**
	 * Filter the A1 Tools API URL.
	 *
	 * Allows developers to override the API endpoint for development or staging environments.
	 *
	 * @since 1.0.0
	 * @param string $api_url The API base URL.
	 */
	$api_base_url = apply_filters( 'a1_tools_api_url', A1_TOOLS_DEFAULT_API_URL );

	$api_url = add_query_arg(
		array(
			'action' => 'public',
			'url'    => $site_url,
		),
		$api_base_url
	);

	$response = wp_remote_get(
		$api_url,
		array(
			'timeout'   => 10,
			'sslverify' => true,
		)
	);

	if ( is_wp_error( $response ) ) {
		return null;
	}

	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	if ( ! isset( $data['success'] ) || true !== $data['success'] ) {
		return null;
	}

	$variables = isset( $data['variables'] ) ? $data['variables'] : array();

	// Cache the result.
	set_transient( A1_TOOLS_CACHE_KEY, $variables, A1_TOOLS_CACHE_EXPIRY );

	return $variables;
}

/**
 * Get a single site variable.
 *
 * @since 1.0.0
 * @param string $key     Variable key (e.g., 'phone_primary', 'facebook_url').
 * @param string $default Default value if not found.
 * @return string Variable value.
 */
function a1_tools_get_variable( $key, $default = '' ) {
	$variables = a1_tools_get_site_variables();

	if ( null === $variables || ! isset( $variables[ $key ] ) ) {
		return $default;
	}

	return $variables[ $key ];
}

/**
 * Clear the site variables cache.
 *
 * @since 1.0.0
 * @return void
 */
function a1_tools_clear_cache() {
	delete_transient( A1_TOOLS_CACHE_KEY );
}

// ============================================================================
// SHORTCODES
// ============================================================================

/**
 * Shortcode: [a1_var key="phone_primary"]
 * Outputs a site variable value.
 *
 * @since 1.0.0
 * @param array $atts Shortcode attributes.
 * @return string Shortcode output.
 */
function a1_tools_shortcode_var( $atts ) {
	$atts = shortcode_atts(
		array(
			'key'     => '',
			'link'    => 'false',
			'target'  => '_blank',
			'class'   => '',
			'default' => '',
		),
		$atts,
		'a1_var'
	);

	if ( empty( $atts['key'] ) ) {
		return '';
	}

	$value = a1_tools_get_variable( $atts['key'], $atts['default'] );

	if ( empty( $value ) ) {
		return esc_html( $atts['default'] );
	}

	// Wrap in link if requested and value is a URL.
	if ( 'true' === $atts['link'] && filter_var( $value, FILTER_VALIDATE_URL ) ) {
		$class_attr = ! empty( $atts['class'] ) ? ' class="' . esc_attr( $atts['class'] ) . '"' : '';
		$rel_attr   = '_blank' === $atts['target'] ? ' rel="noopener noreferrer"' : '';
		return '<a href="' . esc_url( $value ) . '" target="' . esc_attr( $atts['target'] ) . '"' . $rel_attr . $class_attr . '>' . esc_html( $value ) . '</a>';
	}

	// Wrap in span if class provided.
	if ( ! empty( $atts['class'] ) ) {
		return '<span class="' . esc_attr( $atts['class'] ) . '">' . esc_html( $value ) . '</span>';
	}

	return esc_html( $value );
}
add_shortcode( 'a1_var', 'a1_tools_shortcode_var' );

/**
 * Shortcode: [a1_address format="full"]
 * Outputs formatted address.
 *
 * @since 1.0.0
 * @param array $atts Shortcode attributes.
 * @return string Shortcode output.
 */
function a1_tools_shortcode_address( $atts ) {
	$atts = shortcode_atts(
		array(
			'format'    => 'full',
			'separator' => '<br>',
		),
		$atts,
		'a1_address'
	);

	$vars = a1_tools_get_site_variables();
	if ( ! $vars ) {
		return '';
	}

	$parts = array();

	switch ( $atts['format'] ) {
		case 'street':
			$parts = array_filter(
				array(
					isset( $vars['address_line1'] ) ? $vars['address_line1'] : '',
					isset( $vars['address_line2'] ) ? $vars['address_line2'] : '',
				)
			);
			break;

		case 'city_state_zip':
			$city_state = array_filter(
				array(
					isset( $vars['city'] ) ? $vars['city'] : '',
					isset( $vars['state'] ) ? $vars['state'] : '',
				)
			);
			$zip        = isset( $vars['zip'] ) ? $vars['zip'] : '';
			$parts      = array( implode( ', ', $city_state ) . ' ' . $zip );
			break;

		case 'full':
		default:
			$city        = isset( $vars['city'] ) ? $vars['city'] : '';
			$state       = isset( $vars['state'] ) ? $vars['state'] : '';
			$zip         = isset( $vars['zip'] ) ? $vars['zip'] : '';
			$state_zip   = trim( $state . ' ' . $zip );
			$city_line   = $city ? $city . ( $state_zip ? ', ' . $state_zip : '' ) : $state_zip;

			$parts = array_filter(
				array(
					isset( $vars['address_line1'] ) ? $vars['address_line1'] : '',
					isset( $vars['address_line2'] ) ? $vars['address_line2'] : '',
					$city_line,
					isset( $vars['country'] ) ? $vars['country'] : '',
				)
			);
			break;
	}

	// Handle separator - allow <br> for HTML output, otherwise escape.
	$separator = $atts['separator'];
	if ( '<br>' === $separator || '<br/>' === $separator || '<br />' === $separator ) {
		return implode( '<br>', array_map( 'esc_html', $parts ) );
	}

	return esc_html( implode( $separator, $parts ) );
}
add_shortcode( 'a1_address', 'a1_tools_shortcode_address' );

/**
 * Shortcode: [a1_hours]
 * Outputs formatted operating hours table.
 *
 * @since 1.0.0
 * @param array $atts Shortcode attributes.
 * @return string Shortcode output.
 */
function a1_tools_shortcode_hours( $atts ) {
	$atts = shortcode_atts(
		array(
			'format' => 'table',
			'class'  => 'a1-tools-hours',
		),
		$atts,
		'a1_hours'
	);

	$vars = a1_tools_get_site_variables();
	if ( ! $vars || empty( $vars['operating_hours'] ) ) {
		return '';
	}

	$hours = $vars['operating_hours'];
	$days  = array(
		'mon' => __( 'Monday', 'a1-tools' ),
		'tue' => __( 'Tuesday', 'a1-tools' ),
		'wed' => __( 'Wednesday', 'a1-tools' ),
		'thu' => __( 'Thursday', 'a1-tools' ),
		'fri' => __( 'Friday', 'a1-tools' ),
		'sat' => __( 'Saturday', 'a1-tools' ),
		'sun' => __( 'Sunday', 'a1-tools' ),
	);

	$output = '';

	if ( 'list' === $atts['format'] ) {
		$output = '<ul class="' . esc_attr( $atts['class'] ) . '">';
		foreach ( $days as $key => $label ) {
			$time    = isset( $hours[ $key ] ) && ! empty( $hours[ $key ] ) ? esc_html( $hours[ $key ] ) : esc_html__( 'Closed', 'a1-tools' );
			$output .= '<li><strong>' . esc_html( $label ) . ':</strong> ' . $time . '</li>';
		}
		$output .= '</ul>';
	} else {
		$output = '<table class="' . esc_attr( $atts['class'] ) . '">';
		foreach ( $days as $key => $label ) {
			$time    = isset( $hours[ $key ] ) && ! empty( $hours[ $key ] ) ? esc_html( $hours[ $key ] ) : esc_html__( 'Closed', 'a1-tools' );
			$output .= '<tr><td>' . esc_html( $label ) . '</td><td>' . $time . '</td></tr>';
		}
		$output .= '</table>';
	}

	return $output;
}
add_shortcode( 'a1_hours', 'a1_tools_shortcode_hours' );

/**
 * Shortcode: [a1_social_links]
 * Outputs social media icons/links.
 *
 * @since 1.0.0
 * @param array $atts Shortcode attributes.
 * @return string Shortcode output.
 */
function a1_tools_shortcode_social_links( $atts ) {
	$atts = shortcode_atts(
		array(
			'class'      => 'a1-tools-social-links',
			'icon_class' => '',
		),
		$atts,
		'a1_social_links'
	);

	$vars = a1_tools_get_site_variables();
	if ( ! $vars ) {
		return '';
	}

	$platforms = array(
		'facebook_url'        => array(
			'label' => 'Facebook',
			'icon'  => 'fab fa-facebook-f',
		),
		'instagram_url'       => array(
			'label' => 'Instagram',
			'icon'  => 'fab fa-instagram',
		),
		'youtube_url'         => array(
			'label' => 'YouTube',
			'icon'  => 'fab fa-youtube',
		),
		'twitter_url'         => array(
			'label' => 'Twitter',
			'icon'  => 'fab fa-twitter',
		),
		'linkedin_url'        => array(
			'label' => 'LinkedIn',
			'icon'  => 'fab fa-linkedin-in',
		),
		'tiktok_url'          => array(
			'label' => 'TikTok',
			'icon'  => 'fab fa-tiktok',
		),
		'yelp_url'            => array(
			'label' => 'Yelp',
			'icon'  => 'fab fa-yelp',
		),
		'google_business_url' => array(
			'label' => 'Google',
			'icon'  => 'fab fa-google',
		),
	);

	$output = '<div class="' . esc_attr( $atts['class'] ) . '">';

	foreach ( $platforms as $key => $data ) {
		if ( ! empty( $vars[ $key ] ) ) {
			$icon_class = ! empty( $atts['icon_class'] ) ? $atts['icon_class'] : $data['icon'];
			$output    .= '<a href="' . esc_url( $vars[ $key ] ) . '" target="_blank" rel="noopener noreferrer" title="' . esc_attr( $data['label'] ) . '">';
			$output    .= '<i class="' . esc_attr( $icon_class ) . '" aria-hidden="true"></i>';
			$output    .= '<span class="screen-reader-text">' . esc_html( $data['label'] ) . '</span>';
			$output    .= '</a>';
		}
	}

	$output .= '</div>';

	return $output;
}
add_shortcode( 'a1_social_links', 'a1_tools_shortcode_social_links' );

// ============================================================================
// REST API ENDPOINTS
// ============================================================================

/**
 * Register REST API routes.
 *
 * @since 1.0.0
 * @return void
 */
function a1_tools_register_rest_routes() {
	// Get site variables (public).
	register_rest_route(
		'a1-tools/v1',
		'/site-variables',
		array(
			'methods'             => 'GET',
			'callback'            => 'a1_tools_rest_get_variables',
			'permission_callback' => '__return_true',
		)
	);

	// Clear cache (requires admin).
	register_rest_route(
		'a1-tools/v1',
		'/site-variables/clear-cache',
		array(
			'methods'             => 'POST',
			'callback'            => 'a1_tools_rest_clear_cache',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
		)
	);

	// Yoast meta endpoints.
	register_rest_route(
		'a1-tools/v1',
		'/yoast-meta/(?P<id>\d+)',
		array(
			'methods'             => 'POST',
			'callback'            => 'a1_tools_update_yoast_meta',
			'permission_callback' => function () {
				return current_user_can( 'edit_posts' );
			},
			'args'                => array(
				'id' => array(
					'description'       => 'Post ID',
					'type'              => 'integer',
					'required'          => true,
					'validate_callback' => function ( $param ) {
						return is_numeric( $param ) && $param > 0;
					},
				),
			),
		)
	);

	register_rest_route(
		'a1-tools/v1',
		'/yoast-meta/(?P<id>\d+)',
		array(
			'methods'             => 'GET',
			'callback'            => 'a1_tools_get_yoast_meta',
			'permission_callback' => function () {
				return current_user_can( 'edit_posts' );
			},
			'args'                => array(
				'id' => array(
					'description'       => 'Post ID',
					'type'              => 'integer',
					'required'          => true,
					'validate_callback' => function ( $param ) {
						return is_numeric( $param ) && $param > 0;
					},
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'a1_tools_register_rest_routes' );

/**
 * REST: Get site variables.
 *
 * @since 1.0.0
 * @return WP_REST_Response|WP_Error Response object.
 */
function a1_tools_rest_get_variables() {
	$variables = a1_tools_get_site_variables();

	if ( null === $variables ) {
		return new WP_Error( 'fetch_error', __( 'Could not fetch site variables', 'a1-tools' ), array( 'status' => 500 ) );
	}

	return new WP_REST_Response(
		array(
			'success'   => true,
			'variables' => $variables,
			'cached'    => false !== get_transient( A1_TOOLS_CACHE_KEY ),
		),
		200
	);
}

/**
 * REST: Clear variables cache.
 *
 * @since 1.0.0
 * @return WP_REST_Response Response object.
 */
function a1_tools_rest_clear_cache() {
	a1_tools_clear_cache();

	return new WP_REST_Response(
		array(
			'success' => true,
			'message' => __( 'Cache cleared', 'a1-tools' ),
		),
		200
	);
}

// ============================================================================
// YOAST SEO INTEGRATION
// ============================================================================

/**
 * Get Yoast meta field mapping.
 *
 * @since 1.0.0
 * @return array Mapping of API keys to Yoast meta keys.
 */
function a1_tools_get_yoast_meta_mapping() {
	return array(
		'title'                 => '_yoast_wpseo_title',
		'metadesc'              => '_yoast_wpseo_metadesc',
		'focuskw'               => '_yoast_wpseo_focuskw',
		'focuskeywords'         => '_yoast_wpseo_focuskeywords',
		'keywordsynonyms'       => '_yoast_wpseo_keywordsynonyms',
		'meta-robots-noindex'   => '_yoast_wpseo_meta-robots-noindex',
		'meta-robots-nofollow'  => '_yoast_wpseo_meta-robots-nofollow',
		'meta-robots-adv'       => '_yoast_wpseo_meta-robots-adv',
		'canonical'             => '_yoast_wpseo_canonical',
		'redirect'              => '_yoast_wpseo_redirect',
		'is_cornerstone'        => '_yoast_wpseo_is_cornerstone',
		'opengraph-title'       => '_yoast_wpseo_opengraph-title',
		'opengraph-description' => '_yoast_wpseo_opengraph-description',
		'opengraph-image'       => '_yoast_wpseo_opengraph-image',
		'opengraph-image-id'    => '_yoast_wpseo_opengraph-image-id',
		'twitter-title'         => '_yoast_wpseo_twitter-title',
		'twitter-description'   => '_yoast_wpseo_twitter-description',
		'twitter-image'         => '_yoast_wpseo_twitter-image',
		'twitter-image-id'      => '_yoast_wpseo_twitter-image-id',
		'schema_page_type'      => '_yoast_wpseo_schema_page_type',
		'schema_article_type'   => '_yoast_wpseo_schema_article_type',
		'linkdex'               => '_yoast_wpseo_linkdex',
		'content_score'         => '_yoast_wpseo_content_score',
		'primary_category'      => '_yoast_wpseo_primary_category',
	);
}

/**
 * Sanitize Yoast meta value based on field type.
 *
 * @since 1.0.0
 * @param string $key   Field key.
 * @param mixed  $value Value to sanitize.
 * @return mixed Sanitized value.
 */
function a1_tools_sanitize_yoast_value( $key, $value ) {
	$json_fields = array( 'focuskeywords', 'keywordsynonyms' );
	if ( in_array( $key, $json_fields, true ) ) {
		if ( is_array( $value ) ) {
			return wp_json_encode( $value );
		}
		if ( is_string( $value ) ) {
			$decoded = json_decode( $value );
			if ( JSON_ERROR_NONE === json_last_error() ) {
				return $value;
			}
			return wp_json_encode( array( $value ) );
		}
		return '';
	}

	$bool_fields = array( 'is_cornerstone', 'meta-robots-noindex', 'meta-robots-nofollow' );
	if ( in_array( $key, $bool_fields, true ) ) {
		return $value ? '1' : '0';
	}

	$int_fields = array( 'linkdex', 'content_score', 'primary_category', 'opengraph-image-id', 'twitter-image-id' );
	if ( in_array( $key, $int_fields, true ) ) {
		return (int) $value;
	}

	$url_fields = array( 'canonical', 'redirect', 'opengraph-image', 'twitter-image' );
	if ( in_array( $key, $url_fields, true ) ) {
		return esc_url_raw( $value );
	}

	$text_fields = array( 'title', 'metadesc', 'opengraph-title', 'opengraph-description', 'twitter-title', 'twitter-description' );
	if ( in_array( $key, $text_fields, true ) ) {
		return sanitize_text_field( $value );
	}

	if ( is_string( $value ) ) {
		return sanitize_text_field( $value );
	}

	return $value;
}

/**
 * Update Yoast SEO meta fields for a post.
 *
 * @since 1.0.0
 * @param WP_REST_Request $request Request object.
 * @return WP_REST_Response|WP_Error Response object.
 */
function a1_tools_update_yoast_meta( $request ) {
	$post_id = (int) $request['id'];

	$post = get_post( $post_id );
	if ( ! $post ) {
		return new WP_Error( 'post_not_found', __( 'Post not found', 'a1-tools' ), array( 'status' => 404 ) );
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return new WP_Error( 'forbidden', __( 'You do not have permission to edit this post', 'a1-tools' ), array( 'status' => 403 ) );
	}

	$body = $request->get_json_params();
	if ( empty( $body ) ) {
		return new WP_Error( 'no_data', __( 'No data provided', 'a1-tools' ), array( 'status' => 400 ) );
	}

	$mapping = a1_tools_get_yoast_meta_mapping();
	$updated = array();
	$errors  = array();

	foreach ( $body as $key => $value ) {
		if ( isset( $mapping[ $key ] ) ) {
			$meta_key = $mapping[ $key ];
		} elseif ( 0 === strpos( $key, '_yoast_wpseo_' ) ) {
			$meta_key = $key;
		} else {
			continue;
		}

		$sanitized_value = a1_tools_sanitize_yoast_value( $key, $value );
		$result          = update_post_meta( $post_id, $meta_key, $sanitized_value );

		if ( false !== $result ) {
			$updated[ $key ] = $sanitized_value;
		} else {
			$current_value = get_post_meta( $post_id, $meta_key, true );
			if ( $current_value === $sanitized_value || $current_value === (string) $sanitized_value ) {
				$updated[ $key ] = $sanitized_value;
			} else {
				$errors[ $key ] = 'Failed to update';
			}
		}
	}

	if ( class_exists( 'WPSEO_Meta' ) ) {
		do_action( 'wpseo_saved_postdata' );
	}

	return new WP_REST_Response(
		array(
			'success' => true,
			'post_id' => $post_id,
			'updated' => $updated,
			'errors'  => $errors,
		),
		200
	);
}

/**
 * Get Yoast SEO meta fields for a post.
 *
 * @since 1.0.0
 * @param WP_REST_Request $request Request object.
 * @return WP_REST_Response|WP_Error Response object.
 */
function a1_tools_get_yoast_meta( $request ) {
	$post_id = (int) $request['id'];

	$post = get_post( $post_id );
	if ( ! $post ) {
		return new WP_Error( 'post_not_found', __( 'Post not found', 'a1-tools' ), array( 'status' => 404 ) );
	}

	$mapping = a1_tools_get_yoast_meta_mapping();
	$meta    = array();

	foreach ( $mapping as $api_key => $meta_key ) {
		$value = get_post_meta( $post_id, $meta_key, true );
		if ( '' !== $value && false !== $value ) {
			$meta[ $api_key ] = $value;
		}
	}

	return new WP_REST_Response(
		array(
			'success' => true,
			'post_id' => $post_id,
			'meta'    => $meta,
		),
		200
	);
}

// ============================================================================
// ELEMENTOR INTEGRATION
// ============================================================================

/**
 * Register Elementor dynamic tags.
 *
 * @since 1.0.0
 * @param \Elementor\Core\DynamicTags\Manager $dynamic_tags_manager Dynamic tags manager.
 * @return void
 */
function a1_tools_register_elementor_tags( $dynamic_tags_manager ) {
	// Register dynamic tag group.
	$dynamic_tags_manager->register_group(
		'a1-tools',
		array(
			'title' => __( 'A1 Tools', 'a1-tools' ),
		)
	);

	// Include and register the dynamic tag class.
	require_once A1_TOOLS_PLUGIN_DIR . 'includes/class-a1-tools-elementor-tag.php';

	if ( class_exists( 'A1_Tools_Elementor_Tag' ) ) {
		$dynamic_tags_manager->register( new A1_Tools_Elementor_Tag() );
	}
}
add_action( 'elementor/dynamic_tags/register', 'a1_tools_register_elementor_tags' );

// ============================================================================
// ADMIN NOTICES
// ============================================================================

/**
 * Display admin notice if site variables cannot be fetched.
 *
 * @since 1.0.0
 * @return void
 */
function a1_tools_admin_notices() {
	// Only show on plugins page.
	$screen = get_current_screen();
	if ( ! $screen || 'plugins' !== $screen->id ) {
		return;
	}

	$variables = a1_tools_get_site_variables();
	if ( null === $variables ) {
		?>
		<div class="notice notice-warning is-dismissible">
			<p>
				<strong><?php esc_html_e( 'A1 Tools:', 'a1-tools' ); ?></strong>
				<?php esc_html_e( 'Unable to fetch site variables. Make sure this site is configured in A1 Tools.', 'a1-tools' ); ?>
			</p>
		</div>
		<?php
	}
}
add_action( 'admin_notices', 'a1_tools_admin_notices' );
