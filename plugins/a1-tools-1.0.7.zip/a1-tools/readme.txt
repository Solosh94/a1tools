=== A1 Tools ===
Contributors: a1chimney
Tags: site variables, contact info, business information, multi-site, shortcodes
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.0.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Centrally manage contact information, social media links, and business details across your WordPress sites from the A1 Tools platform.

== Description ==

A1 Tools connects your WordPress site to the A1 Tools platform, enabling centralized management of business information that can be displayed anywhere on your site using simple shortcodes.

**Perfect for businesses with multiple websites** - update your phone number, address, or social media links once in the A1 Tools dashboard, and all your connected sites update automatically.

= Features =

* **Centralized Management** - Manage all your site variables from one dashboard
* **Simple Shortcodes** - Display any variable with `[a1_var key="phone_primary"]`
* **Address Formatting** - Multiple address display formats available
* **Operating Hours** - Display business hours as tables or lists
* **Social Media Links** - Output all social icons with one shortcode
* **Elementor Support** - Dynamic tags for Elementor page builder
* **Performance Optimized** - Variables are cached for 1 hour
* **Developer Friendly** - PHP functions available for theme developers

= Available Variables =

* Business name, location name, tagline
* Primary and secondary phone numbers
* Primary and secondary email addresses
* Full address (line 1, line 2, city, state, ZIP, country)
* Social media URLs (Facebook, Instagram, YouTube, Twitter, LinkedIn, TikTok, Yelp, Google Business)
* Operating hours for each day of the week

= Shortcode Examples =

`[a1_var key="phone_primary"]` - Display primary phone number

`[a1_var key="facebook_url" link="true"]` - Display Facebook URL as clickable link

`[a1_address format="full"]` - Display complete formatted address

`[a1_hours format="table"]` - Display operating hours as a table

`[a1_social_links]` - Display all configured social media icons

= Requirements =

* Your WordPress site must be registered in the A1 Tools platform
* An active A1 Tools account with site variables configured

== Installation ==

1. Upload the `a1-tools` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Ensure your site is registered in your A1 Tools dashboard under Integrations > WordPress Sites
4. Configure your site variables in A1 Tools under Marketing Tools > Web Management > Site Variables
5. Use the shortcodes in your pages, posts, or widgets

== Frequently Asked Questions ==

= How do I get an A1 Tools account? =

A1 Tools is a business management platform. Contact A1 Chimney Service for access information.

= Why are my variables not showing? =

1. Verify your site URL in A1 Tools matches your WordPress site URL exactly (including https://)
2. Check that you have saved variables for this site in A1 Tools
3. Wait up to 1 hour for cache to refresh, or clear WordPress transients

= How often do variables update? =

Variables are cached for 1 hour to improve performance. After updating variables in A1 Tools, changes will appear within an hour. You can clear the cache by deleting the WordPress transient or using the REST API endpoint.

= Can I use this with Elementor? =

Yes! The plugin registers dynamic tags that appear under the "A1 Tools" group in Elementor. You can also use the Shortcode widget with any of the available shortcodes.

= Is this plugin free? =

The plugin is free and open source. However, it requires an A1 Tools account to function, as it retrieves data from the A1 Tools platform.

== Screenshots ==

1. Site Variables management in A1 Tools dashboard
2. Using shortcodes in the WordPress editor
3. Elementor dynamic tags integration

== Changelog ==

= 1.0.0 =
* Initial release
* Site variables shortcodes: [a1_var], [a1_address], [a1_hours], [a1_social_links]
* Elementor dynamic tags integration
* REST API endpoints for variable retrieval
* 1-hour caching for performance
* Yoast SEO meta field integration via REST API

== Upgrade Notice ==

= 1.0.0 =
Initial release of A1 Tools plugin.
